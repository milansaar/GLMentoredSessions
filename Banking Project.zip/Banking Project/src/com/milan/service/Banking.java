package com.milan.service;
import java.util.Scanner;

public class Banking {
	int bankBalance = 1000;
	Scanner sc = new Scanner(System.in);
	OTPGenerator generator = new OTPGenerator();
	public void deposit() {
		int amount;
		System.out.println("Please enter the amount you want to deposit.");
		amount = sc.nextInt();
		if(amount>0) {
			System.out.println("Amount " + amount + "deposited successfully.");
			bankBalance += amount;
			System.out.println("Current balance is Rs. " + bankBalance);
		}
		else {
			System.out.println("Please enter valid amount!");
		}
	}
	public void withdrawl() {
		System.out.println("Please enter the amount you want to withdraw.");
		int amount;
		amount = sc.nextInt();
		if(amount>0 && amount<=bankBalance) {
			System.out.println("Withdrawl of Rs. " + amount + "was successful. \n");
			bankBalance -= amount;
			System.out.println("Remaining account balance is Rs. " + bankBalance);
		}
		else {
			System.out.println("Entered amount is greater than the available balance. Please check the current bank balance and then enter the amount.");
		}
	}
	public void transfer() {
		int amount;
		int otp;
		int otpGenerated;
		int bankAccountNo;
		
		otpGenerated = generator.generateOTP();
		System.out.println(otpGenerated);
		System.out.println("Enter the OTP!");
		otp = sc.nextInt();
		
		if(otp == otpGenerated) {
			System.out.println("OTP verified!");
			System.out.println("Please enter the bank account no. of the receiver: ");
			bankAccountNo = sc.nextInt();
			System.out.println("Please enter the amount to be transfered: ");
			amount = sc.nextInt();
			
			if(amount>0 && amount<=bankBalance) {
				System.out.println("Transfer of Rs. " + amount + "was successful to bank account no. "+ bankAccountNo);
				bankBalance -= amount;
				System.out.println("Remaining account balance is Rs. " + bankBalance);
			}
			else {
				System.out.println("Entered amount is greater than the available balance. Please check the current bank balance and then enter the amount.");
			}
		}
		else {
			System.out.println("Invalid OTP, please try again with the correct OTP.");
		}
	}
}
