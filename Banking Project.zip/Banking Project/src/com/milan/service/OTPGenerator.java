package com.milan.service;

public class OTPGenerator {
	public int generateOTP() {
		int randomPIN = 0;
		randomPIN = (int) (Math.random() * 9000) + 1000; 
		
		return randomPIN; 
	}

}
